# RtEx PWA
Esta es una Progressive Web App de ejemplo para desplegar en Vercel.

## Instalación
1. Clona este repositorio.
2. Sube el proyecto a Vercel.

## Autor
Generado automáticamente por ChatGPT.
